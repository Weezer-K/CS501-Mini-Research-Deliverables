# CS501-RunBuddy

Firebase Login Done.

Fake GPS Started.
