package com.fitbit.api.exceptions;

/**
 * Created by jboggess on 9/19/16.
 */
public class TokenExpiredException extends FitbitAPIException {
}
